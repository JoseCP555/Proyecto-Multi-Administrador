from sqlalchemy.orm import Session
from models import Usuario
from datetime import datetime


def crear_usuario(db: Session, usuario):
    nuevo = Usuario(
        nombre=usuario.nombre,
        telefono="",                  # Se deja vacío por defecto
        correo=usuario.correo,
        contrasena_hash=usuario.contrasena,
        id_rol=2,                     # 2 = Residente
        activo=True,                  # Activo por defecto
        fecha_creacion=datetime.utcnow(),
        id_copropiedad=2              # Copropiedad por defecto
    )

    db.add(nuevo)
    db.commit()
    db.refresh(nuevo)

    return nuevo


def obtener_usuarios(db: Session):
    return db.query(Usuario).all()