from sqlalchemy import Column, Integer, String, Boolean, DateTime
from database import Base

class Usuario(Base):
    __tablename__ = "usuarios"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, nullable=False)
    telefono = Column(String)
    correo = Column(String, nullable=False)
    contrasena_hash = Column(String, nullable=False)
    id_rol = Column(Integer, nullable=False)
    activo = Column(Boolean, nullable=False)
    fecha_creacion = Column(DateTime)
    id_copropiedad = Column(Integer)