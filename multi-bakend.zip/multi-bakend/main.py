from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session

from database import Base, engine, SessionLocal
import models
import schemas
import crud

# crear tablas en PostgreSQL
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Multi-Administrador API")

# conexión a DB
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ruta principal
@app.get("/")
def home():
    return {"mensaje": "Backend funcionando con PostgreSQL"}

# crear usuario
@app.post("/crear_usuarios")
def crear_usuario(usuario: schemas.UsuarioCreate, db: Session = Depends(get_db)):
    return crud.crear_usuario(db, usuario)

# listar usuarios
@app.get("/usuarios")
def listar_usuarios(db: Session = Depends(get_db)):
    return crud.obtener_usuarios(db)